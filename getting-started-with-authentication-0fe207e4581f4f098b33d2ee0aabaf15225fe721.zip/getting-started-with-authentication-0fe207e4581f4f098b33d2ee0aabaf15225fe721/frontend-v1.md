# Setting up the version-1 of the front-end

- Download the 